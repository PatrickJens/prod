package Utilities;
import java.io.*;
import java.util.Random;


public class ArrayManager
{
	/* fields */
	private Random r = new Random();

	/* constructors */
	public ArrayManager()
	{
		System.out.println("\nArray Manager object created\nMethods:\n.createIntArray(int size)\n.printIntArray(int[] A)\n\n");
	}


	public int[] createIntArray(int size)
	{
		int[] a = new int[size];
		for(int i = 0 ; i < size ; i ++)
		{
			a[i] = r.nextInt(20);
		}
		return a;
	}

	public void printIntArray(int[] a)
	{
		System.out.println("");
		for(int i = 0 ; i < a.length ; i ++)
		{
			System.out.print(" " + a[i]);
		}
		System.out.println("");
	}
}