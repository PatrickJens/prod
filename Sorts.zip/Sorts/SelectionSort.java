package Sorts;
import java.util.*;
//import prod.*;

//n2
public class SelectionSort
{
	public SelectionSort()
	{}

	public void sort(int[] A)
	{
		int i=0, j=0;
		int minIndex 	= 0;
		int tmp  		= 0;

		for(i=0; i < A.length; i ++)
		{
			minIndex = i;
			for(j=i; j < A.length ; j ++)
			{
				if(A[j] < A[minIndex])
					minIndex = j;
			}
			tmp = A[minIndex];
			A[minIndex] = A[i];
			A[i] = tmp;
		}
	}
}