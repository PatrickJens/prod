package Sorts;
import java.util.*;


public class InsertionSort
{
	public InsertionSort()
	{}

	public void sort(int[] A)
	{
		int i, j;
		int tmp;
		for(i=0; i < A.length; i ++)		// i is the unsorted element. Shift unsorted value thru the sorted subarray
		{
			tmp = A[i];						
			j = i - 1;						// i - 1 is inside the sorted subarray. j iterates through sorted sub array. 
			while( j >= 0 && tmp < A[j] )	// stop when tmp is larger or equal to a sorted element, A[j]
			{
				A[j+1] = A[j];				// A[j] is sorted element. A[j+1] is where unsorted element inserted 
				j--;
			}
			A[j+1] = tmp;							
		}
	}
}

/* 	SAMPLE DATA 

      j i
2 4 8 9 3 6
    j   i  
2 4 8 9 9 6
  j     i
2 4 8 8 9 6
  j     i  
2 4 4 8 9 6

2 3 4 8 9 6      <-- INSERT
*/