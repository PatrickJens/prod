package Sorts;
import java.util.*;

public class MergeSort
{
	public MergeSort()
	{}

	public int[] sort(int[] A)
	{
		int start 	= 0;
		int end 	= A.length - 1;
		int[] B = mergesort(A, start, end);
		return B;
	}

	private int[] mergesort(int[] A, int start, int end)
	{
		/* Base case: leaf node has length equal to one */
		if(start == end){
			System.out.println("Base Case");
			return A;
		}
		int leftEnd = (end+start)/2;			// subarray L end 	point
		int rightStart = leftEnd + 1;			// subarray R start point

		/* Divide and Conquer */
		mergesort(A, start, leftEnd);
		mergesort(A, rightStart, end);

		/* Merge */								//assume returned subarrays are sorted.
		int i = start;
		int j = rightStart;
		int k = start;
		int[] B = new int[A.length];
		while( i <= leftEnd && j <= end){
			if( A[i] < A[j])
				B[k++] = A[i++];
			else
				B[k++] = A[j++];
		}
		while( i <= leftEnd){
			B[k++] = A[i++];
		}
		while( j <= end){
			B[k++] = A[j++];
		}

		/* Copy B into A */
		k = start;
		while(k <= end){
			A[k] = B[k];
			k++;
		}

		return A;
	}
}