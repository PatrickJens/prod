package Sorts;
import java.util.*;

public class BubbleSort
{
	public BubbleSort()
	{}

	public void sort(int[] A)
	{
		int i=0, j=0;
		int tmp = 0;

		for(i=0; i < A.length; i ++)
		{
			for(j= A.length - 1; j > i ; j--)
			{
				if( A[j] < A[j-1])
				{
					tmp = A[j];
					A[j] = A[j-1];
					A[j-1] = tmp;
				}
			}
		}
	}
}