package Sorts;
import java.util.*;

public class MergeSort_old
{
	public MergeSort()
	{}

	public void sort(int[] A, int length)
	{

		if( length == 1)
			return;

		int mid = length/2;
		int[] left = new int[mid];
		int[] right = new int[length - mid];
	
		for(int i = 0; i < mid; i++)
		{
			left[i] = A[i];
			//System.out.print(left[i] + " ");
		}

		//System.out.println("\nright: ");
		for( int i = mid; i < length ; i ++ )
		{
			right[i - mid] = A[i];
			//System.out.print(right[i - mid]+ " ");
		}

		//int[] B, C;
		sort(left, mid);
		sort(right, length - mid);

		int i =0, j=0, k=0;


		while( i < left.length && j < right.length )
		{
			if( left[i] <= right[j])
			{
				A[k] = left[i];
				i++; k++;
			}
			else
			{
				A[k] = right[j];
				j++; k++;
			}
		}

		while(i < left.length)
		{
			A[k] = left[i];
			i++; k++;
		}

		while( j < right.length)
		{
			A[k] = right[j];
			j++; k ++;
		}

		//return;
	}
}