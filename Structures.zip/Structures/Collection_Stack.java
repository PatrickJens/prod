//package prod;
import java.util.*;
//import prod.*;

public class Collection_Stack
{
	public static void main(String[] args)
	{
		Stack<Integer> stack = new Stack<Integer>();

		stack.push(1);
		stack.push(2);
		stack.push(3);

		while(!stack.empty()){
			System.out.println(stack.pop());
		}
	}
}