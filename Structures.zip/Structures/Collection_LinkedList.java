//package prod;
import java.util.*;
//import prod.*;

//FIFO implementation of LinkedList, aka Queue
public class Collection_LinkedList
{
	public static void main(String[] args)
	{
		LinkedList<Integer> queue = new LinkedList<Integer>();

		queue.addFirst(1);
		queue.addFirst(2);
		queue.addFirst(3);

		System.out.println(""+queue.getLast());
		while(queue.size() > 0){
			System.out.println(queue.removeLast());
		}
	}
}