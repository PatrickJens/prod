
DELETE A
FROM test A, test B
WHERE A.val = B.val AND A.id > B.id; #these are the values we want to remove

SELECT * from test;