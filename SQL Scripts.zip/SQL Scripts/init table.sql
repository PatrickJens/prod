INSERT INTO test (id, val)
VALUES(1,'a'),(2,'b'),(3,'c'),(4,'c'),(5,'b'),(6,'a'),(7,'b');
