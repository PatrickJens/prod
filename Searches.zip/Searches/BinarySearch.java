package prod;
import java.util.*;

public class BinarySearch
{
	public BinarySearch(){
		System.out.println("BinarySearch object created");
	}

	public int search(int[] A, int t){
		int lo = 0;
		int hi = A.length - 1;
		int mid;

		while(lo <= hi)
		{
			mid = (hi + lo)/2;
			if( t < A[mid])
				hi = mid - 1;
			else if( t > A[mid])
				lo = mid + 1;
			else
				return mid;
		}

		return -1;
	}
}